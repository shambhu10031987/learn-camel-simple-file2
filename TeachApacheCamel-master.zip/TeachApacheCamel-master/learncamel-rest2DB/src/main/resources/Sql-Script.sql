
CREATE TABLE country_capital
(
    countryName text ,
    capital text,
    create_date timestamp without time zone DEFAULT now()
);